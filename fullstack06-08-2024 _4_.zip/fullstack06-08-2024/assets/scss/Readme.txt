The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/